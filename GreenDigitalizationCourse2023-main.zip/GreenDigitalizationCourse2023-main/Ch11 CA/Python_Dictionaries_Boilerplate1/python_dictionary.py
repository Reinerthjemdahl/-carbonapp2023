#1.a Create a dictionary.


#1.b. Accessing an entry in a dictionary


#1.c. Updating an entry in a dictionary


#1.d. Deleting an entry


#1.e. Know with type of Python component is efco2


#2.a. Create a dictionary inside a dictionary


#2.b. Accessing an entry in a dictionary


#3. Python methods in a dictionary


#3.a. dictionary.get() method


#3.b. dictionary.items() method


#3.c. dictionary.keys() method


#3.d. dictionary.values() method


#4.a. Looping Techniques 


#4.b. Looping Techniques 

