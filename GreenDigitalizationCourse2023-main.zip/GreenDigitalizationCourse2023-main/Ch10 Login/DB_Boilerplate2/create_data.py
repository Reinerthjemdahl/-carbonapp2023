from capp import db
db.create_all()
